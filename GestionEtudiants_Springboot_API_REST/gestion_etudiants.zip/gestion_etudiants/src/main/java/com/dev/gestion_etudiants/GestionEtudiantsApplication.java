package com.dev.gestion_etudiants;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GestionEtudiantsApplication {

	public static void main(String[] args) {
		SpringApplication.run(GestionEtudiantsApplication.class, args);
	}

}
