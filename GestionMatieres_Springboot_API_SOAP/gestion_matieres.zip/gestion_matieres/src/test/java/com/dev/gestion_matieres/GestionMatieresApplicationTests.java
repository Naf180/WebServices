package com.dev.gestion_matieres;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestionMatieresApplicationTests {

	@Test
	void contextLoads() {
	}

}
