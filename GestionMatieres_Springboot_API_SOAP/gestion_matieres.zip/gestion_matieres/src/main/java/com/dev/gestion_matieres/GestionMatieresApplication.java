package com.dev.gestion_matieres;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GestionMatieresApplication {

	public static void main(String[] args) {
		SpringApplication.run(GestionMatieresApplication.class, args);
	}

}
