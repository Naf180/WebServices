package com.dev.gestion_classes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestionClassesApplicationTests {

	@Test
	void contextLoads() {
	}

}
